# Farkle
Farkle dice game where which one or more players try to score a predetermined number of points based on the dice that they roll. On their turn, each player will roll six dice. If they roll a one, five, three of a kind, or straight of five to six dice in a row, they earn points that add up to their total score.

Rules:

![Farkel Welcome](https://github.com/user-attachments/assets/781e81db-34b9-4060-b4d1-1c62515e9090)

Setup:

![Farkle Setup](https://github.com/user-attachments/assets/1ef2484e-2f49-4298-a85c-77cf0cd61f64)

Checking player score:

![Farkle points](https://github.com/user-attachments/assets/c6fb6966-1a14-4eda-87da-145aa9140c8d)

Win:

![Farkle End](https://github.com/user-attachments/assets/3b3729b6-c94f-45b5-8919-a6a9ed7d63bb)

